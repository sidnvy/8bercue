#!/bin/sh
zig ranlib "$@"
