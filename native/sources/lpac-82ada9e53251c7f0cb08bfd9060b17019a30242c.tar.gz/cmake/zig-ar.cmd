@echo off
zig ar %*