@echo off
zig ranlib %*